var searchData=
[
  ['taubinlm',['TaubinLM',['../namespacegeoproc.html#a396280579199558902594f4df72c01c7ad69ec4945f39affa518f05fa077b00ae',1,'geoproc']]]
];
