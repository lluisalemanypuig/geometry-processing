var searchData=
[
  ['curvature_2ehpp',['curvature.hpp',['../curvature_8hpp.html',1,'']]]
];
