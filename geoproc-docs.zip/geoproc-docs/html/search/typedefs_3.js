var searchData=
[
  ['vectorf',['Vectorf',['../namespacegeoproc_1_1parametrisation.html#ae7c3f0e55b5cc67a95acb18387d3e0b9',1,'geoproc::parametrisation::Vectorf()'],['../namespacegeoproc_1_1smoothing_1_1global.html#a0eb78ce82d055fe9414c8f7d947e97dd',1,'geoproc::smoothing::global::Vectorf()']]]
];
