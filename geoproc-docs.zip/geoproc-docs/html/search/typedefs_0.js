var searchData=
[
  ['matrixf',['Matrixf',['../namespacegeoproc_1_1parametrisation.html#a818792d45f3fd0151517ce69c9842558',1,'geoproc::parametrisation::Matrixf()'],['../namespacegeoproc_1_1smoothing_1_1global.html#a6f5d12821de397515052cf45251171d7',1,'geoproc::smoothing::global::Matrixf()']]]
];
