var searchData=
[
  ['scale_5fto_5funit',['scale_to_unit',['../classgeoproc_1_1TriangleMesh.html#a2b34ddfa21f906805451e6dbbb4ce064',1,'geoproc::TriangleMesh']]],
  ['set_5ftriangles',['set_triangles',['../classgeoproc_1_1TriangleMesh.html#a5e35cad5c18195e6397f22bc951161f1',1,'geoproc::TriangleMesh']]],
  ['set_5fvertices',['set_vertices',['../classgeoproc_1_1TriangleMesh.html#acdee6975fe8d504956211a154adbf77c',1,'geoproc::TriangleMesh::set_vertices(const std::vector&lt; double &gt; &amp;coords)'],['../classgeoproc_1_1TriangleMesh.html#a6a22ba5b1e8dcf735c104fa03b01f7ae',1,'geoproc::TriangleMesh::set_vertices(const glm::vec3d *vs, int N)'],['../classgeoproc_1_1TriangleMesh.html#a8ec1bd0a9ff539251ee3750eedc694b3',1,'geoproc::TriangleMesh::set_vertices(const std::vector&lt; glm::vec3d &gt; &amp;vs)']]],
  ['smooth',['smooth',['../namespacegeoproc_1_1smoothing_1_1global.html#ac6c034cb72d0a744d0dd843d4df012ff',1,'geoproc::smoothing::global']]]
];
