var searchData=
[
  ['copy_5fmesh',['copy_mesh',['../classgeoproc_1_1TriangleMesh.html#a1680c786572ac504621f253b7407d4f7',1,'geoproc::TriangleMesh']]],
  ['current',['current',['../classgeoproc_1_1iterators_1_1mesh__iterator.html#ae6151b065602980d37a582977083ef42',1,'geoproc::iterators::mesh_iterator::current()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__vertex__iterator.html#a3e1a4cd5c67b262156017489662ecabc',1,'geoproc::iterators::vertex::vertex_vertex_iterator::current()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__face__iterator.html#aa75fe423e210cf4e20e721307c80f6fb',1,'geoproc::iterators::vertex::vertex_face_iterator::current()']]]
];
