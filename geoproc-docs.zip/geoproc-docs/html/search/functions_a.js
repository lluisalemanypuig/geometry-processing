var searchData=
[
  ['read_5fmesh',['read_mesh',['../namespacegeoproc_1_1PLY__reader.html#a7b13df3c66f0cf33b5ae96ad3302d2e2',1,'geoproc::PLY_reader']]]
];
