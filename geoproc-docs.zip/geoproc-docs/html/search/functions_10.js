var searchData=
[
  ['taubinlm',['TaubinLM',['../namespacegeoproc_1_1smoothing_1_1local.html#acb46f51bf5fefe33b36ae6d7e0c4a899',1,'geoproc::smoothing::local::TaubinLM(const smooth_weight &amp;w, float lambda, size_t n_iter, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1smoothing_1_1local.html#ae68c255cdba405972ce42238aee04c3b',1,'geoproc::smoothing::local::TaubinLM(const smooth_weight &amp;w, float lambda, size_t n_iter, size_t nt, TriangleMesh &amp;m)']]],
  ['tri_5fhas_5fedge_5fshare_5fvertex',['tri_has_edge_share_vertex',['../triangle__mesh__algs_8cpp.html#a1a6a1412055493817b792247a210f925',1,'triangle_mesh_algs.cpp']]],
  ['trianglemesh',['TriangleMesh',['../classgeoproc_1_1TriangleMesh.html#a73c49980eb81e2df75242515b5ef1ed7',1,'geoproc::TriangleMesh::TriangleMesh()'],['../classgeoproc_1_1TriangleMesh.html#ae660da7765a405ac44640d2ad46a6903',1,'geoproc::TriangleMesh::TriangleMesh(const TriangleMesh &amp;m)']]]
];
