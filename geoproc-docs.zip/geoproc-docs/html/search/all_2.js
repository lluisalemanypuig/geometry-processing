var searchData=
[
  ['circle',['Circle',['../namespacegeoproc.html#a494da744a805b80f842402f0a806ccfca30954d90085f6eaaf5817917fc5fecb3',1,'geoproc']]],
  ['copy_5fmesh',['copy_mesh',['../classgeoproc_1_1TriangleMesh.html#a1680c786572ac504621f253b7407d4f7',1,'geoproc::TriangleMesh']]],
  ['corners',['corners',['../classgeoproc_1_1TriangleMesh.html#ab9610d614e081deb28010d237fecd55b',1,'geoproc::TriangleMesh']]],
  ['cotangent',['cotangent',['../namespacegeoproc.html#a12e5a10581b53b9dd9a509127527f843a8e8ea879f40475ae2c70be8b296bf950',1,'geoproc']]],
  ['cur_5fcorner',['cur_corner',['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__vertex__iterator.html#a76628cb7b70644f2e1804c5ea52c94f7',1,'geoproc::iterators::vertex::vertex_vertex_iterator::cur_corner()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__face__iterator.html#a3e59b193d3d83c32a803528a0661672b',1,'geoproc::iterators::vertex::vertex_face_iterator::cur_corner()']]],
  ['cur_5fface',['cur_face',['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__face__iterator.html#ac7cecb32cc46b910764b56b977ca8366',1,'geoproc::iterators::vertex::vertex_face_iterator']]],
  ['cur_5fvertex',['cur_vertex',['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__vertex__iterator.html#a94e6bf674777a2e825678df7aba64ebd',1,'geoproc::iterators::vertex::vertex_vertex_iterator']]],
  ['current',['current',['../classgeoproc_1_1iterators_1_1mesh__iterator.html#ae6151b065602980d37a582977083ef42',1,'geoproc::iterators::mesh_iterator::current()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__vertex__iterator.html#a3e1a4cd5c67b262156017489662ecabc',1,'geoproc::iterators::vertex::vertex_vertex_iterator::current()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__face__iterator.html#aa75fe423e210cf4e20e721307c80f6fb',1,'geoproc::iterators::vertex::vertex_face_iterator::current()']]]
];
