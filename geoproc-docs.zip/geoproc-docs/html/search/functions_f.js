var searchData=
[
  ['scale_5fto_5funit',['scale_to_unit',['../classgeoproc_1_1TriangleMesh.html#a2b34ddfa21f906805451e6dbbb4ce064',1,'geoproc::TriangleMesh']]],
  ['set_5ftriangles',['set_triangles',['../classgeoproc_1_1TriangleMesh.html#a5e35cad5c18195e6397f22bc951161f1',1,'geoproc::TriangleMesh']]],
  ['set_5fvertices',['set_vertices',['../classgeoproc_1_1TriangleMesh.html#aa9ca26f1ededecd289d1a8800dca2c23',1,'geoproc::TriangleMesh::set_vertices(const std::vector&lt; float &gt; &amp;coords)'],['../classgeoproc_1_1TriangleMesh.html#a09b76789e908062501de253d360e0236',1,'geoproc::TriangleMesh::set_vertices(const glm::vec3 *vs, int N)'],['../classgeoproc_1_1TriangleMesh.html#a2bd9a343db1642d11b39b6fab5710d3a',1,'geoproc::TriangleMesh::set_vertices(const std::vector&lt; glm::vec3 &gt; &amp;vs)']]],
  ['smooth',['smooth',['../namespacegeoproc_1_1smoothing_1_1global.html#a88d112d5f1b9f92add0247ec762ddf62',1,'geoproc::smoothing::global::smooth(const smooth_operator &amp;op, const smooth_weight &amp;w, const vector&lt; bool &gt; &amp;constant, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1smoothing_1_1global.html#a7e294855e2c00be2b1141aa3f4e2650a',1,'geoproc::smoothing::global::smooth(const smooth_operator &amp;op, const smooth_weight &amp;w, const std::vector&lt; bool &gt; &amp;constant, TriangleMesh &amp;m)']]]
];
