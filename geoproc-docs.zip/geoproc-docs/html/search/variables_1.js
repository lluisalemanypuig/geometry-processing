var searchData=
[
  ['boundaries',['boundaries',['../classgeoproc_1_1TriangleMesh.html#a57162eac37831c87786a8dab8331d72f',1,'geoproc::TriangleMesh']]],
  ['boundaries_5fvalid',['boundaries_valid',['../classgeoproc_1_1TriangleMesh.html#a1384fa834aaa4ec3dc7c3b025b1ca528',1,'geoproc::TriangleMesh']]],
  ['boundary_5fedges',['boundary_edges',['../classgeoproc_1_1TriangleMesh.html#a142a764ddf07b98c7efcd596d88c3f87',1,'geoproc::TriangleMesh']]]
];
