var searchData=
[
  ['taubinlm',['TaubinLM',['../namespacegeoproc_1_1smoothing_1_1local.html#ac234b9f2b455e7dbc97b71bb6c9c47d3',1,'geoproc::smoothing::local::TaubinLM(const weight &amp;w, double lambda, size_t n_iter, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1smoothing_1_1local.html#a05133ca078331bc4fe3e95104c35d3af',1,'geoproc::smoothing::local::TaubinLM(const weight &amp;w, double lambda, size_t n_iter, size_t nt, TriangleMesh &amp;m)'],['../namespacegeoproc.html#a396280579199558902594f4df72c01c7ad69ec4945f39affa518f05fa077b00ae',1,'geoproc::TaubinLM()']]],
  ['trianglemesh',['TriangleMesh',['../classgeoproc_1_1TriangleMesh.html',1,'geoproc::TriangleMesh'],['../classgeoproc_1_1TriangleMesh.html#a73c49980eb81e2df75242515b5ef1ed7',1,'geoproc::TriangleMesh::TriangleMesh()'],['../classgeoproc_1_1TriangleMesh.html#ae660da7765a405ac44640d2ad46a6903',1,'geoproc::TriangleMesh::TriangleMesh(const TriangleMesh &amp;m)']]],
  ['triangles',['triangles',['../classgeoproc_1_1TriangleMesh.html#ad1cf20622f2bb080100862f413bd89c2',1,'geoproc::TriangleMesh']]]
];
