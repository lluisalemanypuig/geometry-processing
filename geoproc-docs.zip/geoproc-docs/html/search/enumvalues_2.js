var searchData=
[
  ['laplacian',['Laplacian',['../namespacegeoproc.html#a396280579199558902594f4df72c01c7a799723f39baf497704a3d39e7c03555f',1,'geoproc']]]
];
