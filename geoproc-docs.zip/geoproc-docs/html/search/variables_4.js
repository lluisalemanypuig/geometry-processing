var searchData=
[
  ['half_5fstep',['half_step',['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__vertex__iterator.html#a3e22144ee36c4739d316aca005e17d87',1,'geoproc::iterators::vertex::vertex_vertex_iterator']]]
];
