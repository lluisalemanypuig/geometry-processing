var searchData=
[
  ['init',['init',['../classgeoproc_1_1iterators_1_1mesh__iterator.html#a8a4d8b5c84941dd0a7cb7373abcd3fcc',1,'geoproc::iterators::mesh_iterator::init()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__vertex__iterator.html#aa25d74c5f4067074ed6926a6d23800b4',1,'geoproc::iterators::vertex::vertex_vertex_iterator::init()'],['../classgeoproc_1_1iterators_1_1vertex_1_1vertex__face__iterator.html#a713d8d9edb7121c729b5717261fd8b3b',1,'geoproc::iterators::vertex::vertex_face_iterator::init()']]],
  ['invalidate_5fareas_5fangles',['invalidate_areas_angles',['../classgeoproc_1_1TriangleMesh.html#aace37defd7566fed311222b7e22264a5',1,'geoproc::TriangleMesh']]],
  ['invalidate_5fboundaries',['invalidate_boundaries',['../classgeoproc_1_1TriangleMesh.html#af8c9c5ef993c961f24cdf189a990e6e8',1,'geoproc::TriangleMesh']]],
  ['invalidate_5fneighbourhood',['invalidate_neighbourhood',['../classgeoproc_1_1TriangleMesh.html#add9ebc58773a0127b9a0467d33cfe3c6',1,'geoproc::TriangleMesh']]],
  ['invalidate_5fstate',['invalidate_state',['../classgeoproc_1_1TriangleMesh.html#af83d7e4da9103a2d4ce965955b4520f7',1,'geoproc::TriangleMesh']]],
  ['is_5fneighbourhood_5fvalid',['is_neighbourhood_valid',['../classgeoproc_1_1TriangleMesh.html#aa6f95b95709a72a14a15638bfeeed3f9',1,'geoproc::TriangleMesh']]]
];
