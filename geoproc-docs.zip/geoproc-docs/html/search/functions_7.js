var searchData=
[
  ['laplacian',['laplacian',['../namespacegeoproc_1_1smoothing_1_1local.html#aca304df02cb346b9786b22fa3fb80c88',1,'geoproc::smoothing::local::laplacian(const weight &amp;w, double lambda, size_t n_iter, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1smoothing_1_1local.html#aeb4e9f73796dce51c4dcac3c1e824fa7',1,'geoproc::smoothing::local::laplacian(const weight &amp;w, double lambda, size_t n_iter, size_t nt, TriangleMesh &amp;m)']]]
];
