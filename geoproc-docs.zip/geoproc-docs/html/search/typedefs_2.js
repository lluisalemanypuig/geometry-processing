var searchData=
[
  ['t',['T',['../namespacegeoproc_1_1parametrisation.html#a167d0e7733242219092b6ea9bc6d094f',1,'geoproc::parametrisation::T()'],['../namespacegeoproc_1_1smoothing_1_1global.html#af3871957d239adf08dce428d5ca6bbe2',1,'geoproc::smoothing::global::T()']]]
];
