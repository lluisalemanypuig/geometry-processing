var searchData=
[
  ['make_5fangles_5farea',['make_angles_area',['../classgeoproc_1_1TriangleMesh.html#a4657d7986fd9905c3a7b759e3d1b5442',1,'geoproc::TriangleMesh']]],
  ['make_5fboundaries',['make_boundaries',['../classgeoproc_1_1TriangleMesh.html#ad11c9406e2677e4d72d53837206fd769',1,'geoproc::TriangleMesh']]],
  ['make_5fcotangent_5fweight',['make_cotangent_weight',['../namespacegeoproc_1_1smoothing_1_1local__private.html#ad5c1b8a2f5202da2837c7c5bcb03beff',1,'geoproc::smoothing::local_private']]],
  ['make_5fcotangent_5fweights',['make_cotangent_weights',['../namespacegeoproc_1_1smoothing_1_1local__private.html#a258b6f254a89ea6773e6b59cbe16e4f5',1,'geoproc::smoothing::local_private']]],
  ['make_5fneighbourhood_5fdata',['make_neighbourhood_data',['../classgeoproc_1_1TriangleMesh.html#a84003dfdfd5e591c00f01a797578ff1f',1,'geoproc::TriangleMesh']]],
  ['make_5fnormal_5fvectors',['make_normal_vectors',['../classgeoproc_1_1TriangleMesh.html#a638f0267d7d8e51498330e414fa25bfe',1,'geoproc::TriangleMesh']]],
  ['make_5funiform_5fweight',['make_uniform_weight',['../namespacegeoproc_1_1smoothing_1_1local__private.html#a8be790d814ab013aaf5d4e1c48af0ed7',1,'geoproc::smoothing::local_private']]],
  ['make_5funiform_5fweights',['make_uniform_weights',['../namespacegeoproc_1_1smoothing_1_1local__private.html#a04fc2ea113fcafa38210c562dca3d735',1,'geoproc::smoothing::local_private']]],
  ['mean',['mean',['../namespacegeoproc_1_1curvature.html#a9ccfeae3d3672f6627f4de90bd8ffb0c',1,'geoproc::curvature::mean(const TriangleMesh &amp;mesh, std::vector&lt; double &gt; &amp;Kh, double *min=nullptr, double *max=nullptr)'],['../namespacegeoproc_1_1curvature.html#a4d1846571b144ee15bd828156bd5f256',1,'geoproc::curvature::mean(const TriangleMesh &amp;mesh, std::vector&lt; double &gt; &amp;Kh, size_t n_threads)'],['../namespacegeoproc_1_1curvature.html#ae649b189f6b14d3dd42fcace8a0e804a',1,'geoproc::curvature::mean(const TriangleMesh &amp;mesh, std::vector&lt; double &gt; &amp;Kh, size_t n_threads, double *min, double *max)']]],
  ['mesh_5fedge',['mesh_edge',['../classgeoproc_1_1mesh__edge.html#ab54d5cca1a94addee7c591bd8a7e553b',1,'geoproc::mesh_edge::mesh_edge()'],['../classgeoproc_1_1mesh__edge.html#a67841c3983cd67cf346bf23cb15411bf',1,'geoproc::mesh_edge::mesh_edge(int pv, int nv, int lt, int rt)'],['../classgeoproc_1_1mesh__edge.html#adcd094f91449248c574402dff022b94f',1,'geoproc::mesh_edge::mesh_edge(const mesh_edge &amp;m)']]],
  ['mesh_5fiterator',['mesh_iterator',['../classgeoproc_1_1iterators_1_1mesh__iterator.html#a785c3bccc57fd4db49de8aa89bc2d04e',1,'geoproc::iterators::mesh_iterator']]]
];
