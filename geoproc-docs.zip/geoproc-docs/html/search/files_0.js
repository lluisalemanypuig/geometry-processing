var searchData=
[
  ['band_5ffrequencies_2ecpp',['band_frequencies.cpp',['../band__frequencies_8cpp.html',1,'']]],
  ['band_5ffrequencies_2ehpp',['band_frequencies.hpp',['../band__frequencies_8hpp.html',1,'']]]
];
