var searchData=
[
  ['so',['so',['../structgeoproc_1_1filter__frequencies_1_1smoothing__configuration.html#aa384c253639793b2230cb744444b97c2',1,'geoproc::filter_frequencies::smoothing_configuration']]],
  ['sw',['sw',['../structgeoproc_1_1filter__frequencies_1_1smoothing__configuration.html#a29f89d7b9df8ad82ed3759af569d8e67',1,'geoproc::filter_frequencies::smoothing_configuration']]]
];
