var searchData=
[
  ['opposite_5fcorners',['opposite_corners',['../classgeoproc_1_1TriangleMesh.html#a2604795c90c694116513252b86d242b4',1,'geoproc::TriangleMesh']]]
];
