var searchData=
[
  ['sparsematrixf',['SparseMatrixf',['../namespacegeoproc_1_1parametrisation.html#a9b8f62d41ba8cba6e03693ef62ffe028',1,'geoproc::parametrisation::SparseMatrixf()'],['../namespacegeoproc_1_1smoothing_1_1global.html#abd018025dbba5d44debd6fb35c14a8d9',1,'geoproc::smoothing::global::SparseMatrixf()']]]
];
