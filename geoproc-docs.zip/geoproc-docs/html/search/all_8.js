var searchData=
[
  ['lambda',['lambda',['../structgeoproc_1_1filter__frequencies_1_1smoothing__configuration.html#a801c2ab0af402978ec941776e1d20d00',1,'geoproc::filter_frequencies::smoothing_configuration']]],
  ['laplacian',['Laplacian',['../namespacegeoproc.html#a396280579199558902594f4df72c01c7a799723f39baf497704a3d39e7c03555f',1,'geoproc::Laplacian()'],['../namespacegeoproc_1_1smoothing_1_1local.html#aca304df02cb346b9786b22fa3fb80c88',1,'geoproc::smoothing::local::laplacian(const weight &amp;w, double lambda, size_t n_iter, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1smoothing_1_1local.html#aeb4e9f73796dce51c4dcac3c1e824fa7',1,'geoproc::smoothing::local::laplacian(const weight &amp;w, double lambda, size_t n_iter, size_t nt, TriangleMesh &amp;m)']]],
  ['lt',['lT',['../classgeoproc_1_1mesh__edge.html#a348d06b420ce1588be1bc7eac781c6ef',1,'geoproc::mesh_edge']]]
];
