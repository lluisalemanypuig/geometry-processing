var searchData=
[
  ['n_5fit',['n_it',['../structgeoproc_1_1filter__frequencies_1_1smoothing__configuration.html#aa9f5a87ca7e0084e9ac6f3c40d30310c',1,'geoproc::filter_frequencies::smoothing_configuration']]],
  ['ne',['nE',['../classgeoproc_1_1mesh__edge.html#a4ae9cbf7d6c147e75233df48d0451859',1,'geoproc::mesh_edge']]],
  ['neigh_5fvalid',['neigh_valid',['../classgeoproc_1_1TriangleMesh.html#a21205ec88e494f864db4d8247db70d3c',1,'geoproc::TriangleMesh']]],
  ['normal_5fvectors',['normal_vectors',['../classgeoproc_1_1TriangleMesh.html#a9fa270e81bcf0b9acf03696d9d0c9264',1,'geoproc::TriangleMesh']]]
];
