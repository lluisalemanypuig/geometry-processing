var searchData=
[
  ['band_5ffrequencies',['band_frequencies',['../namespacegeoproc_1_1filter__frequencies.html#a9a3d38dda8f7703607998e250e264a7c',1,'geoproc::filter_frequencies::band_frequencies(const std::vector&lt; smoothing_configuration &gt; &amp;confs, const std::vector&lt; double &gt; &amp;mus, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1filter__frequencies.html#a186988c0c5cb1fa64125db078846814e',1,'geoproc::filter_frequencies::band_frequencies(const std::vector&lt; smoothing_configuration &gt; &amp;confs, const std::vector&lt; double &gt; &amp;mus, size_t nt, TriangleMesh &amp;m)']]],
  ['bilaplacian',['BiLaplacian',['../namespacegeoproc.html#a396280579199558902594f4df72c01c7a0890724bffb79f511bc768c0529dce3f',1,'geoproc::BiLaplacian()'],['../namespacegeoproc_1_1smoothing_1_1local.html#ae414b9bd00610e2f63096ab8c087b5ea',1,'geoproc::smoothing::local::bilaplacian(const weight &amp;w, double lambda, size_t n_iter, TriangleMesh &amp;m)'],['../namespacegeoproc_1_1smoothing_1_1local.html#a57fc04667cb54871012f162f6af1deed',1,'geoproc::smoothing::local::bilaplacian(const weight &amp;w, double lambda, size_t n_iter, size_t nt, TriangleMesh &amp;m)']]],
  ['boundaries',['boundaries',['../classgeoproc_1_1TriangleMesh.html#a57162eac37831c87786a8dab8331d72f',1,'geoproc::TriangleMesh']]],
  ['boundaries_5fvalid',['boundaries_valid',['../classgeoproc_1_1TriangleMesh.html#a1384fa834aaa4ec3dc7c3b025b1ca528',1,'geoproc::TriangleMesh']]],
  ['boundary_5fedges',['boundary_edges',['../classgeoproc_1_1TriangleMesh.html#a142a764ddf07b98c7efcd596d88c3f87',1,'geoproc::TriangleMesh']]],
  ['boundary_5fshape',['boundary_shape',['../namespacegeoproc.html#a494da744a805b80f842402f0a806ccfc',1,'geoproc']]]
];
